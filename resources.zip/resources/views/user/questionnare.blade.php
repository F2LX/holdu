@extends('ui.home')

@section('content')
    @livewire('modals')
@endsection