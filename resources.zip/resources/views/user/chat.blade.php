@extends('ui.home')

@section('content')
    @livewire('chatcom')
@endsection