<div>
<!--[if BLOCK]><![endif]--><?php if(!$is_profile): ?>
    <form class="d-flex mb-3 mt-4 gap-2" wire:submit="search">
        <input type="text" id="" wire:model="keyword" class="form-control" placeholder="Search Here..." required>
        <button type="submit" class="btn btn-primary px-5 py-1">
            <span class="material-symbols-outlined">
                search
                </span>
        </button>
    </form>

    <!--[if BLOCK]><![endif]--><?php if(!$users): ?>
    <div class="w-100">
        <form wire:submit="save">
            <textarea class="w-100 textarea-connectu" wire:model="content" id="" cols="30" rows="10" placeholder="What's on your mind?" required></textarea>
            <button type="submit" class="btn btn-primary">
                Submit
            </button>
        </form>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
    <!--[if BLOCK]><![endif]--><?php if($users): ?>
    <a class="btn btn-primary mb-3 mt-1" href="#posts">See Posts</a>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-100 bg-white p-3 d-flex align-items-center">
            <img class="thumbnail-connectu" src="<?php echo e(asset("img/".$user->category)); ?>" alt="">
            <a href="info/<?php echo e($user->username); ?>"><p class="fw-bold"><?php echo e($user->username); ?></p>
                <!--[if BLOCK]><![endif]--><?php if($user->is_verified): ?>
                <div class="ms-4 d-flex flex-row align-items-center bg-primary rounded-5 text-light tag-verified">
                    <span class="material-symbols-outlined">
                      check
                      </span>
                    <p class="mb-0">Psychologist</p>
                  </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </a>
            
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <div x-intersect.full="$wire.loadMoreUsers()" class="w-100 d-flex justify-content-center align-items-center text-center p-4">
            <div wire:loading wire:target="loadMoreUsers" 
                  class="loading-indicator">
                     Loading more posts...  
            </div>
          </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <div class="posts w-100" id="posts">
        <div class="w-100 d-flex justify-content-center align-items-center">
            <button class="btn btn-primary rounded-5 d-flex justify-content-center align-items-center mr-2" wire:click="$refresh"><span class="material-symbols-outlined">
                refresh
                </span> Refresh</button>
        </div>
        
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="post">
            <div class="d-flex align-items-center post-header justify-content-between
            w-100">
                <div class="d-flex justify-content-center align-items-center">
                <img class="thumbnail-connectu" src="<?php echo e(asset("img/".$post->user->category)); ?>" alt="">
                <a href="info/<?php echo e($post->user->username); ?>"><p class="m-0 fw-bold"><?php echo e($post->user->username); ?></p></a>
                <!--[if BLOCK]><![endif]--><?php if($post->user->is_verified): ?>
                <div class="ms-4 d-flex flex-row align-items-center bg-primary rounded-5 text-light tag-verified">
                    <span class="material-symbols-outlined">
                      check
                      </span>
                    <p class="mb-0">Psychologist</p>
                  </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <div>
                <!--[if BLOCK]><![endif]--><?php if(auth()->user()->id==$post->user->id): ?>
                <button class="btn btn-danger float-right" wire:click="delete(<?php echo e($post->id); ?>)" type="button">Delete</button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
            
            <p><?php echo e($post->content); ?></p>
            <!--[if BLOCK]><![endif]--><?php if($post->comments): ?>
            <div class="w-100 d-flex flex-direction-row flex-wrap comment-section">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--[if BLOCK]><![endif]--><?php if($comment->parent_id===null): ?>
                <div class="w-100 comment-wrap">
                    <div class="d-flex">
                        <img class="thumbnail-comment" src="<?php echo e(asset("img/".$comment->user->category)); ?>" alt="">
                        <div class="d-flex flex-direction-column flex-wrap w-100">
                            <p class="w-100 comment-text">
                                <a href="info/<?php echo e($comment->user->username); ?>"><span class="fw-bold <?php echo e($comment->user->is_verified?'color-verified':''); ?>"><?php echo e($comment->user->username); ?></span></a> <br>
                                <?php echo e($comment->content); ?></p><br>
                                <button class="btn btn-default reply-btn px-3" id="btn-show-form-<?php echo e($comment->id); ?>" type="button" data-comment-id="<?php echo e($comment->id); ?>">Reply</button>
                                <?php if(auth()->user()->id==$comment->user->id): ?>
                                    <button class="btn btn-default reply-btn float-right ml-5" wire:click="deletecomment(<?php echo e($comment->id); ?>)" type="button">Delete</button>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <form id="reply-form-<?php echo e($comment->id); ?>" wire:submit="comment(<?php echo e($post->id); ?>,<?php echo e($comment->id); ?>)" class="w-100 gap-2" style="display: none ">
                                    <input type="text" class="form-control form-comment" wire:model="replymsgs.<?php echo e($post->id); ?>" placeholder="Comment Here" required>
                                    <button class="btn btn-primary btn-send" type="submit">Send</button>
                                </form>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentReply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!--[if BLOCK]><![endif]--><?php if($commentReply->parent_id==$comment->id): ?>
                                    <div class="w-100 comment-wrap ms-2">
                                        <div class="d-flex">
                                            <img class="thumbnail-comment" src="<?php echo e(asset("img/".$commentReply->user->category)); ?>" alt="">
                                            <div class="d-flex flex-direction-column flex-wrap w-100">
                                                <p class="w-100 comment-text">
                                                    <a href="info/<?php echo e($commentReply->user->username); ?>"><span class="fw-bold <?php echo e($commentReply->user->is_verified?'color-verified':''); ?>"><?php echo e($commentReply->user->username); ?></span></a> <br>
                                                    <?php echo e($commentReply->content); ?></p><br>
                                                    <?php if(auth()->user()->id==$commentReply->user->id): ?>
                                                        <button class="btn btn-default reply-btn float-right ml-5" wire:click="deletecomment(<?php echo e($commentReply->id); ?>)" type="button">Delete</button>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                
                        </div>
                    </div>
                </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <form wire:submit="comment(<?php echo e($post->id); ?>,null)" class="w-100 d-flex gap-2">
                <input type="text" class="form-control form-comment" wire:model="commentmsgs.<?php echo e($post->id); ?>" placeholder="Comment here..." required>
                <button class="btn btn-primary btn-send" type="submit">Send</button>
            </form>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <div x-intersect.full="$wire.loadMore()" class="w-100 d-flex justify-content-center align-items-center text-center p-4">
            <div wire:loading wire:target="loadMore" 
                  class="loading-indicator">
                     Loading more posts...  
            </div>
          </div>
    </div>
        <?php
        $__scriptKey = '341855422-0';
        ob_start();
    ?>
        <script>
            document.addEventListener('click', function(event) {
                if (event.target.classList.contains('reply-btn')) {
                    const commentId = event.target.dataset.commentId;
                    const replyForm = document.getElementById(`reply-form-${commentId}`);
                    if (replyForm) {
                        replyForm.style.display = replyForm.style.display === 'none' ? 'flex' : 'none';
                    }
                }
            });
           
        </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
<?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\holdu\resources\views/livewire/connectu-main.blade.php ENDPATH**/ ?>