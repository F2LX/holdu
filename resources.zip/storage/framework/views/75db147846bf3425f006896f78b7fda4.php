    
    <div class="modal fade" id="multiStepForm" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header justify-content-center">
            <h1 class="modal-title fs-5" id="exampleModalToggleLabel">Mood Analysis</h1>
            </div>
            <div class="modal-body">
            <form id="stepForm">
                <div id="step1">
                <h3>Have you felt low on energy in the past 14 days?</h3>
                <div class="modal-footer d-flex flex-row align-items-center justify-content-center">
                    <div class="modal-footer d-flex flex-row align-items-center justify-content-center">
                        <p>Disagree</p>         
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="1" > 
                            <span>1</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio"> 
                            <input type="radio" name="1" value="2" > 
                            <span>2</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="3" > 
                            <span>3</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="4" > 
                            <span>4</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="5" > 
                            <span>5</span>
                        </label> 
                        </div> 
                        <p>Agree</p>
                    </div>
                </div>
                </div>
                <div id="step2" style="display: none;">
                <h3>Have you had any thoughts of harming yourself or others?</h3>
                <div class="modal-footer d-flex flex-row align-items-center justify-content-center">
                    <div class="modal-footer d-flex flex-row align-items-center justify-content-center">
                        <p>Disagree</p>         
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="1" > 
                            <span>1</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio"> 
                            <input type="radio" name="1" value="2" > 
                            <span>2</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="3" > 
                            <span>3</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="4" > 
                            <span>4</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="5" > 
                            <span>5</span>
                        </label> 
                        </div> 
                        <p>Agree</p>
                    </div>
                </div>
                </div>
                <div id="step3" style="display: none;">
                <h3>Are you finding it difficult to concentrate or focus on tasks?</h3>
                <div class="modal-footer d-flex flex-row align-items-center justify-content-center">
                    <div class="modal-footer d-flex flex-row align-items-center justify-content-center">
                        <p>Disagree</p>         
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="1" > 
                            <span>1</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio"> 
                            <input type="radio" name="1" value="2" > 
                            <span>2</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="3" > 
                            <span>3</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="4" > 
                            <span>4</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="5" > 
                            <span>5</span>
                        </label> 
                        </div> 
                        <p>Agree</p>
                    </div>
                </div>
                </div>
                <div id="step4" style="display: none;">
                <h3>Are you feeling more irritable or easily frustrated than usual in the past 14 days?</h3>
                <div class="modal-footer d-flex flex-row align-items-center justify-content-center">
                    <div class="modal-footer d-flex flex-row align-items-center justify-content-center">
                        <p>Disagree</p>         
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="1" > 
                            <span>1</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio"> 
                            <input type="radio" name="1" value="2" > 
                            <span>2</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="3" > 
                            <span>3</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="4" > 
                            <span>4</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="5" > 
                            <span>5</span>
                        </label> 
                        </div> 
                        <p>Agree</p>
                    </div>
                </div>
                </div>
                <div id="step5" style="display: none;">
                <h3>Have you been feeling more anxious or worried than usual?</h3>
                <div class="modal-footer d-flex flex-row align-items-center justify-content-center">
                    <div class="modal-footer d-flex flex-row align-items-center justify-content-center">
                        <p>Disagree</p>         
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="1" > 
                            <span>1</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio"> 
                            <input type="radio" name="1" value="2" > 
                            <span>2</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="3" > 
                            <span>3</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="4" > 
                            <span>4</span>
                        </label> 
                        </div> 
                        <div class="col text-center"> 
                        <label class="radio p-0"> 
                            <input type="radio" name="1" value="5" > 
                            <span>5</span>
                        </label> 
                        </div> 
                        <p>Agree</p>
                    </div>
                </div>
                </div>
            </form>
            </div>
            <div class="button mt-4 text-left">
            <button id="prevBtn" class="btn btn-secondary" onclick="prevStep()">Previous</button>
            <button id="nextBtn" class="btn btn-primary" onclick="nextStep()">Next</button>
            </div>
        </div>
        </div>
    </div>
    

    <?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            var currentStep = 1;

            function showStep(stepNumber) {
                $('#step' + currentStep).hide();
                $('#step' + stepNumber).show();
                currentStep = stepNumber;
                updateButtons();
            }

            function prevStep() {
                if (currentStep > 1) {
                    showStep(currentStep - 1);
                }
            }

            function nextStep() {
                if (currentStep < 5) {
                    showStep(currentStep + 1);
                } else {
                    $('#multiStepForm').modal('hide');
                }
            }

            function updateButtons() {
                if (currentStep === 1) {
                    $('#prevBtn').hide();
                } else {
                    $('#prevBtn').show();
                }

                if (currentStep === 5) {
                    $('#nextBtn').text('Submit');
                } else {
                    $('#nextBtn').text('Next');
                }
            }

            // Initial setup
            showStep(1);
            $('#multiStepForm').modal('show');
        });
    </script>
    
    <?php $__env->stopPush(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\holdu\resources\views/ui/modals.blade.php ENDPATH**/ ?>