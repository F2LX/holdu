    <div class="max-full-height">
    <div class="container d-flex align-items-center justify-content-center flex-column">
        <div class="chat-place mt-4" id="chat-place">
            <div class="chat-box d-flex flex-column">
                <div class="d-flex flex-row-reverse">
                    <h6 class="mb-0 width-90">Sana</h6>
                </div>
                <div class="d-flex flex-row mt-0">
                    <div class="col-1">
                        <img src="img/SanaPic 5.png" class="sana-profile-pic" alt="">
                    </div>
                    <div class="col-8 bg-light p-4 rounded-4 bubble-chat">
                        <p class="mb-0 text-message">Hello! How are you feeling today? I'm <b>Sana</b> from HoldU, here to support you through any challenges you may be facing. Whether you're feeling stressed, lonely, or simply want someone to talk to, I'm here to lend a listening ear. So, how has your day been so far?</p>
                        <p class="mb-0 text-end text-date">Now</p>
                    </div>
                </div>
            </div>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!--[if BLOCK]><![endif]--><?php if($message->is_bot): ?>
            <div class="chat-box d-flex flex-column" wire:key="<?php echo e($message->id); ?>">
                <div class="d-flex flex-row-reverse">
                    <h6 class="mb-0 width-90">Sana</h6>
                </div>
                <div class="d-flex flex-row mt-0">
                    <div class="col-1">
                        <img src="img/SanaPic 5.png" class="sana-profile-pic" alt="">
                    </div>
                    <div class="col-8 bg-light p-4 rounded-4 bubble-chat">
                        <p class="mb-0 text-message"><?php echo $message->message; ?></p>
                        <p class="mb-0 text-end text-date"><?php echo e($message->created_at); ?></p>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="chat-box flex-column justify-content-end" wire:key="<?php echo e($message->id); ?>">
                    <h6 class="mb-0 width-90 text-end"><?php echo e(auth()->user()->name); ?></h6>
                <div class="d-flex flex-row justify-content-end">
                    <div class="col-8 bg-light p-4 rounded-4 bubble-chat">
                        <p class="mb-0 text-message"><?php echo e($message->message); ?></p>
                        <p class="mb-0 text-end text-date"><?php echo e($message->created_at); ?></p>
                    </div>
                    <div class="col-1">
                        <img src="<?php echo e(asset("img/".auth()->user()->category)); ?>" class="sana-profile-pic" alt="">
                    </div>
                </div>
            </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            <div id="loading-bubble-wrap" class="display-none-loading">
                <div class="chat-box d-flex flex-column">
                    <div class="d-flex flex-row-reverse">
                        <h6 class="mb-0 width-90">Sana</h6>
                    </div>
                    <div class="d-flex flex-row mt-0">
                        <div class="col-1">
                            <img src="img/SanaPic 5.png" class="sana-profile-pic" alt="">
                        </div>
                        <div class="col-8 bg-light p-4 rounded-4 bubble-chat bubble-loading">
                            <div class="mb-0 text-message">
                                <div class="loader">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
    <!--[if BLOCK]><![endif]--><?php if(session('status')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <form wire:submit="save">
            <div class="form-chat mb-3 mt-5">
                    <input type="text" wire:model="message" placeholder="Type your message..." class="form-size me-3" placeholder="" aria-label="Chat Form" aria-describedby="button-addon1" required>
                    <button class="btn btn-outline-secondary bg-success d-flex justify-content-center align-items-center" type="submit">
                        <span class="text-success-emphasis material-symbols-outlined fs-3">
                            send
                        </span>
                    </button>
            </div>
        </form>
            <?php
        $__scriptKey = '3987107551-0';
        ob_start();
    ?>
        <script>
            const loadingDiv = document.getElementById("loading-bubble-wrap");
        const chatDiv = document.getElementById("chat-place");
        chatDiv.scrollTop = chatDiv.scrollHeight;

        $wire.on('chat-sended', () => {
            setTimeout(() => {
                const lastMessage = chatDiv.lastElementChild;
                lastMessage.scrollIntoView({ behavior: 'smooth' });
            }, 100); // Delay 100ms
        });

        $wire.on('bot-loading', () => {
            setTimeout(() => {
                loadingDiv.classList.remove('display-none-loading');
            }, 100); // Delay 100ms
        });

        $wire.on('bot-finished', () => {
            setTimeout(() => {
                loadingDiv.classList.add('display-none-loading');
                setTimeout(() => {
                    chatDiv.scrollTop = chatDiv.scrollHeight; // Scroll ke bawah setelah loading selesai
                }, 200); // Delay 100ms
            }, 100); // Delay 100ms
        });
        </script>
            <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
<?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\holdu\resources\views/livewire/chatcom.blade.php ENDPATH**/ ?>