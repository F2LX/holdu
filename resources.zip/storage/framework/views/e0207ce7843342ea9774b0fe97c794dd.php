<?php $__env->startSection('content'); ?>

<div class="container">


    <div class="d-flex flex-wrap w-100">
        <div class="wider p-2">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('connectumain');

$__html = app('livewire')->mount($__name, $__params, 'lw-1316059565-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
        <div class="sidebar p-2">
            <div class="category-bar mt-4">
                <h2>My Profile</h2>
                <ul>
                    <li>Username: <?php echo e(auth()->user()->username); ?></li>
                </ul>
            </div>
            <a href="/chat">
                <div class="banner-bar">
                    <img class="banner-pic" src="<?php echo e(asset("img/SanaPic 3.png")); ?>" alt="">
                    <h3>Chat with Sana</h3>
                    <p>Your AI Companion at HoldU. Empathetic, insightful, and always there for you on your journey to wellness. Let Sana illuminate your path to inner peace and growth.</p>
                </div>
            </a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\holdu\resources\views/user/connectu/home.blade.php ENDPATH**/ ?>