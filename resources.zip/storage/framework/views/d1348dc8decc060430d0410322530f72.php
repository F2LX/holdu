<?php $__env->startSection('content'); ?>
    <div class="container">
        <p class="mb-0 mt-5">Monday , 3 December 2024</p>
        <h3 class="fw-bold">Mood History</h3>
        <p>Your mood history are predicted using HoldU's Machine Learning algorithm</p>
    </div>
    <div class="container">
        <?php $__currentLoopData = $quiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="#" class="connect-box d-flex flex-direction-column align-items-center flex-wrap p-3 rounded-4">
            <h4 class="w-100"><?php echo e($q->score); ?></h4>
            <p><?php echo e($q->date); ?></p>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\holdu\resources\views/user/moodhistory.blade.php ENDPATH**/ ?>