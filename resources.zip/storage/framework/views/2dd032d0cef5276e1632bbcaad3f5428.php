<div class="posts w-100">
    <div class="post">
        <div class="d-flex align-items-center post-header">
            <img class="thumbnail-connectu" src="<?php echo e(asset("img/Tomato.png")); ?>" alt="">
            <p class="m-0 fw-bold">Tomato</p>
        </div>
        
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Praesentium sunt sed mollitia, veritatis delectus rerum nihil exercitationem explicabo eius ipsum quis, molestias vitae voluptas, voluptatum nostrum consequatur quae ratione repellat?</p>
            <form action="" class="w-100 d-flex gap-2">
                <input type="text" class="form-control form-comment" id="" placeholder="Comment Here">
                <button class="btn btn-primary btn-send">Send</button>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('post-modal');

$__html = app('livewire')->mount($__name, $__params, 'lw-3239501808-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </form>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#postModal">
                View Post
            </button>
        </div>
    </div>
</div><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\holdu\resources\views/livewire/post-list.blade.php ENDPATH**/ ?>