<?php $__env->startSection('content'); ?>
    <div class="container">
        <p class="mb-0 mt-5">Monday , 3 December 2024</p>
        <h3 class="fw-bold">Mindful Moments: Your HoldU Reminder Hub</h3>
        
    </div>
    <div class="container">
        <a href="#" class="connect-box d-flex justify-content-center p-3 rounded-4">
            <h2>Click me!</h2>
        </a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\holdu\resources\views/user/reminder.blade.php ENDPATH**/ ?>