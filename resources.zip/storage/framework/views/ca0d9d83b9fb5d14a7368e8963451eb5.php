<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HoldU - Mental Health Matters</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    
    <link rel="stylesheet" href="<?php echo e(asset("css/style.css")); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset("css/mobile.css")); ?>">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

    
    <link rel="stylesheet" href="<?php echo e(asset("css/preloader.css")); ?>">

  </head>

  <body>
    
    <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="/"><img class="logo" src="<?php echo e(asset("img/white.png")); ?>" alt=""></a>
          <button class="bg-light navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('/')? 'active' : ''); ?>" aria-current="page" href="/">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('features')? 'active' : ''); ?>" href="/features">Features</a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('pricing')? 'active' : ''); ?>" href="/pricing">Pricing</a>
              </li>
              <?php if(auth()->user()): ?>
              <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard')? 'active' : ''); ?>" href="/dashboard">Dashboard</a>
              </li>
              <?php endif; ?>
              <?php if(auth()->user()): ?>
              <li class="nav-item">
                <a class="nav-link" href="/logout"><span class="material-symbols-outlined">
                  logout
                  </span></a>
              </li>
              <?php endif; ?>
              <li class="nav-item">
                <?php if(!auth()->user()): ?>
                 <a class="nav-link btn btn-light" href="/login">Login</a>
                <?php else: ?>
                 <a class="nav-link btn btn-light d-flex justify-content-center align-items-center" href="/profile"><span class="material-symbols-outlined pe-2">
                  account_circle
                  </span><?php echo e(auth()->user()->name); ?></a>
                <?php endif; ?>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <?php echo $__env->yieldContent('content'); ?>
      
      <?php echo $__env->make('ui.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(!request()->is('chat')): ?>
    <footer class="w-100 h-100 pt-5 bg-dark mt-5">
      <div class="container w-100">
        <div class="footer-box">
          <div class="col-4 d-flex flex-column w-100-mobile">
            <img class="sit-pic" src="<?php echo e(asset("img/white.png")); ?>" alt="">
            <p class="text-light"><span class="fw-bold">HoldU, </span>Your sanctuary for mental <br> wellness. Explore personalized <br> resources, connect with a <br> supportive community, and <br> embark on your journey to inner <br> balance.</p>
          </div>
          <div class="col-4 d-flex flex-column gap-3 mt-3 w-100-mobile">
            <div class="social-box">
              <img class="social-pic" src="<?php echo e(asset("img/Instagram.png")); ?>" alt="">
              <h6 class="text-light mb-0">holduforever</h6>
            </div>
            <div class="social-box">
              <img class="social-pic" src="<?php echo e(asset("img/X.png")); ?>" alt="">
              <h6 class="text-light mb-0">holduforever</h6>
            </div>
            <div class="social-box">
              <img class="social-pic" src="<?php echo e(asset("img/facebook.png")); ?>" alt="">
              <h6 class="text-light mb-0">holduforever</h6>
            </div>
          </div>
          <div class="col-4 d-flex flex-column mt-3 w-100-mobile">
            <h3 class="fw-bold text-light mb-0">Contact Us</h3>
            <p class="text-light mb-0">Hotline: 021-2313-1201</p>
            <p class="text-light">Email: supportholdu@gmail.com</p>
          </div>
        </div>
      </div>
      <p class="text-center text-light mt-footer mb-0">Empowering Minds, Supporting Hearts: HoldU - Your Trusted Companion for Mental Wellness. © 2024 HoldU. All rights reserved.</p>
    </footer>
    <?php endif; ?>
    
    <script src="<?php echo e(asset("js/preloader.js")); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <?php if(request()->is('meditation/track')): ?>
    <script src="<?php echo e(asset("assets/vendor/libs/plyr/plyr.js")); ?>"></script>
    <?php endif; ?>

  </body>
</html><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\holdu\resources\views/ui/home.blade.php ENDPATH**/ ?>