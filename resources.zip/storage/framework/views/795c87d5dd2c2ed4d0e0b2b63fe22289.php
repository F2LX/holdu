<div>
    <div class="modal fade" id="postModal" tabindex="-1" role="dialog" aria-labelledby="postModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="postModalLabel">Title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Et dolore nobis ipsam molestiae accusamus doloremque natus sapiente, nemo voluptate non asperiores pariatur. Ullam repellendus tenetur deleniti pariatur ad doloribus enim.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\holdu\resources\views/livewire/post-modal.blade.php ENDPATH**/ ?>