<?php $__env->startSection('content'); ?>

<div class="container p-3">
    <?php if(session('success')): ?>
        <div class="alert alert-success mt-2 mb-2" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-error mt-2 mb-2" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <h3 class="fw-bold mt-4 m-2">My Journal</h3>
    <p class="m-2">Discover inner insights with HoldU's My Journal. Track emotions, set goals, and reflect on daily experiences in a secure space, fostering personal growth.</p>

    <a href="/journal/add" class="m-2 btn btn-success d-flex flex-row btn-normal"><span class="material-symbols-outlined">
        description
        </span>Write new journal</a>


    <div class="d-flex flex-column w-100 mt-4 chat-place gap-2">
        <?php $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="container w-100 bg-primary rounded-3 p-3">
                <a href="/journal/view/<?php echo e($journal->id); ?>"><h3 class="text-light"><?php echo e($journal->title); ?></h3></a>
                <p class="mb-0">Written on <?php echo e($journal->created_at); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>    
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\holdu\resources\views/user/journal/journal.blade.php ENDPATH**/ ?>