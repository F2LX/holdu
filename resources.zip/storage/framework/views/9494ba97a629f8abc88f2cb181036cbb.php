<?php $__env->startSection('content'); ?>
    <div class="container d-flex justify-content-center">
        <div class="d-flex align-items-center connect-box w-50 justify-content-center flex-column mt-4 rounded-4 p-3">
            <div class="d-flex justify-content-center mb-3">
                <img class="rounded-3 mushroom" src="<?php echo e(asset("img/$user->category")); ?>" alt="">
            </div>
            <h5><?php echo e($user->name); ?></h5>
            <p><?php echo e($user->email); ?></p>

            <div class="d-flex flex-column w-100 p-4">
                <div class="d-flex flex-row justify-content-between">
                    <p>Subscription Type:</p>
                    <p>Demo Account</p>
                </div>
                <div class="d-flex flex-row justify-content-between">
                    <p>Valid Until:</p>
                    <p>Demo Account</p>
                </div>
                <?php if($user->username): ?>
                <div class="d-flex flex-row justify-content-between">
                    <p>Current Username: </p>
                    <p><?php echo e($user->username); ?></p>
                </div>
                <?php endif; ?>
                
            </div>
            <form action="/profile/username" method="post">
                <?php echo csrf_field(); ?>
                <button class="btn btn-primary">Generate New Username</button>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\holdu\resources\views/user/profile.blade.php ENDPATH**/ ?>