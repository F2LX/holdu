<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center bg-primary pt-4 pb-4 rounded-5">
        <div class="col-5 d-flex flex-column justify-content-center">
            <div class="rounded-5 d-flex align-item-center justify-content-center">
                <img class="info-pic" src=<?php echo e(asset("img/".$user->category)); ?> alt="">
            </div>
        </div>
        <div class="col-7 d-flex flex-column p-0">
            <div class="d-flex flex-row gap-3 align-items-center mb-2 flex-wrap">
                <h4 class="fw-bold text-light mb-0"><?php echo e($user->username); ?></h4>
                <?php if($user->is_verified): ?>
                <div class="d-flex flex-row align-items-center rounded-5 bg-success p-1">
                    
                    <span class="material-symbols-outlined fs-mini">
                        check
                        </span>
                    <p class="mb-0 fs-mini">Psychologist</p>
                   
                </div>
                <?php endif; ?>
            </div>
            <h6 class="text-light">Member since <?php echo e($user->created_at); ?></h6>
        </div>
    </div>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('connectu-main', ['userId' => $user->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2648030676-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\holdu\resources\views/user/connectu/info.blade.php ENDPATH**/ ?>